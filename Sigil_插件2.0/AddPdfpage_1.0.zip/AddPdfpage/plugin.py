﻿#!/usr/bin/env python
#-*- coding: utf-8 -*-

from __future__ import unicode_literals, division, absolute_import, print_function
# from shaw.myfunc import Jump2directory
# from myfunc import Jump2directory
import sys
import re
from lxml import etree
from tkinter import *



class HandlerPdfpage():

    def __init__(self, bk):
        self.bk = bk


    # 判断是否有toc.xhtml和 mulu.xhtml, 如果没有则不处理
    def isProcess(self):
        flag = False
        textList = [file for file,_ in self.bk.text_iter()]
        # print(textList)
        if "toc.xhtml" not in textList:
            print("未找到 toc.xhtml 目录文件...")
            return flag
        if "mulu.xhtml" not in textList:
            print("未找到 mulu.xhtml 目录文件...")
            return flag
        flag = True
        return flag


    # 解析xml
    def getXml(self, html):
        xml = etree.fromstring(html.encode("utf-8"))
        ns = xml.nsmap.get(None)
        ns = "{%s}" % ns
        return xml, ns


    # 分析mulu.xhtml 文件， 获取目录章节关键信息,   章节名——page
    def getChapterInfo(self, muluXhtml):
        xml, ns = self.getXml(muluXhtml)
        # 获取 navPoint 节点 列表
        chapterList = xml.findall("{0}body//{0}p".format(ns))
        res = []
        for chapter in chapterList:
            # print(chapter.text.split(" "))
            try:
                tempList = chapter.text.split(" ")
                page = int(tempList[-1])
                chapterName = " ".join(tempList[:-1])
                chapterToPage = [chapterName, page]
                res.append(chapterToPage)
            except:
                continue
        return res


    # 处理toc.xhtml 目录文件
    def processTocXhtml(self,html,chapterList):
        # 获取toc.xhtml中的章节
        xml, ns = self.getXml(html)
        # 获取 标题 a 节点 列表
        aList = xml.findall("{0}body//{0}a".format(ns))
        # print(aList)
        index = None
        for i in range(len(aList)):
            text = aList[i].find("{}span".format(ns)).text
            print(text.strip() + "————>" + chapterList[0][0].strip())
            if text.strip() == chapterList[0][0].strip():
                index = i
                break
        if index is not None:
            aList =  aList[i:]
        else:
            aList = []
        if len(chapterList) == len(aList):
            print("ok")
            # 往toc.xhtm 添加pdfpage
            offset = self.getOffset()

            self.addPdfpageToChapter(aList, chapterList, offset, ns)

            html = etree.tostring(xml, encoding="utf-8").decode("utf-8")
            print("pdfpage 添加完成")
        else:
            print("mulu与toc章节无法对应，未做任何处理！")
        return html

    def addPdfpageToChapter(self, aList, chapterList, offset, ns):
        for i in range(len(aList)):
            pdfpage = chapterList[i][1] + offset
            aList[i].set("pdfpage", str(pdfpage))


    # 此处有一个问题 文件的 <html xmlns="http://www...> 中的内容在自动生成xhtlm文件的时候
    # 可能会有部分属性缺失的情况，看需不需要特殊处理
    def processText(self):

        if self.isProcess():
            muluXhtml = self.bk.readfile("mulu.xhtml")
            tocXhtml = self.bk.readfile("toc.xhtml")
            chapterList = self.getChapterInfo(muluXhtml)
            for chapter in chapterList:
                print(chapter)
            html = self.processTocXhtml(tocXhtml, chapterList)
            if not html == tocXhtml:
                self.bk.writefile("toc.xhtml", html)
            print("toc已处理完毕...")
        else:
            print("文件未做任何处理...")
        print("程序已退出！")


    def getInput(self, title, message):
        def return_callback(event):
            print('quit...')
            root.quit()
        def close_callback():
            tkMessageBox.showinfo('message', 'no click...')
        root = Tk(className=title)
        root.wm_attributes('-topmost', 1)
        screenwidth, screenheight = root.maxsize()
        width = 300
        height = 100
        size = '%dx%d+%d+%d' % (width, height, (screenwidth - width)/2, (screenheight - height)/2)
        root.geometry(size)
        root.resizable(0, 0)
        label = Label(root, height=2)
        label['text'] = message
        label.pack()
        entry = Entry(root)
        entry.bind('<Return>', return_callback)
        entry.pack()
        entry.focus_set()
        root.protocol("WM_DELETE_WINDOW", close_callback)
        root.mainloop()
        str = entry.get()
        root.destroy()
        return str


    def getOffset(self):
        strInput = self.getInput("修正pdfpage", "请输入偏移量（+）：")
        try:
            offset = int(strInput)
            return offset
        except:
            print("ERROR， 请输入整数！")




def run(bk):
    # # # 处理内容
    hp = HandlerPdfpage(bk)
    # hp.getTocInfo()
    hp.processText()
    return 0

def main():
    print("I reached main when I should not have\n")
    return -1

if __name__ == "__main__":
    sys.exit(main())